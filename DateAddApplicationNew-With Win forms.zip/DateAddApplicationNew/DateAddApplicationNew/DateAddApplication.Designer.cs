﻿namespace DateAddApplicationNew
{
    partial class DateAddApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDate = new System.Windows.Forms.Label();
            this.lblNoOfDays = new System.Windows.Forms.Label();
            this.dtPicker = new System.Windows.Forms.DateTimePicker();
            this.txtNoOfDays = new System.Windows.Forms.TextBox();
            this.btnNewDate = new System.Windows.Forms.Button();
            this.lblErrorMsg = new System.Windows.Forms.Label();
            this.lblNewDate = new System.Windows.Forms.Label();
            this.lblDateAddHeader = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.Location = new System.Drawing.Point(76, 104);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(97, 20);
            this.lblDate.TabIndex = 0;
            this.lblDate.Text = "Select Date ";
            // 
            // lblNoOfDays
            // 
            this.lblNoOfDays.AutoSize = true;
            this.lblNoOfDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNoOfDays.Location = new System.Drawing.Point(76, 147);
            this.lblNoOfDays.Name = "lblNoOfDays";
            this.lblNoOfDays.Size = new System.Drawing.Size(224, 20);
            this.lblNoOfDays.TabIndex = 1;
            this.lblNoOfDays.Text = "Enter No.Of Days to be Added";
            // 
            // dtPicker
            // 
            this.dtPicker.CustomFormat = "dd/MM/yyyy";
            this.dtPicker.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtPicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtPicker.Location = new System.Drawing.Point(348, 104);
            this.dtPicker.Name = "dtPicker";
            this.dtPicker.Size = new System.Drawing.Size(200, 22);
            this.dtPicker.TabIndex = 2;
            // 
            // txtNoOfDays
            // 
            this.txtNoOfDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoOfDays.Location = new System.Drawing.Point(348, 147);
            this.txtNoOfDays.Name = "txtNoOfDays";
            this.txtNoOfDays.Size = new System.Drawing.Size(39, 22);
            this.txtNoOfDays.TabIndex = 3;
            this.txtNoOfDays.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNoOfDays_KeyPress);
            // 
            // btnNewDate
            // 
            this.btnNewDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewDate.Location = new System.Drawing.Point(233, 224);
            this.btnNewDate.Name = "btnNewDate";
            this.btnNewDate.Size = new System.Drawing.Size(130, 36);
            this.btnNewDate.TabIndex = 4;
            this.btnNewDate.Text = "New Date";
            this.btnNewDate.UseVisualStyleBackColor = true;
            this.btnNewDate.Click += new System.EventHandler(this.btnNewDate_Click);
            // 
            // lblErrorMsg
            // 
            this.lblErrorMsg.AutoSize = true;
            this.lblErrorMsg.ForeColor = System.Drawing.Color.Maroon;
            this.lblErrorMsg.Location = new System.Drawing.Point(387, 150);
            this.lblErrorMsg.Name = "lblErrorMsg";
            this.lblErrorMsg.Size = new System.Drawing.Size(0, 13);
            this.lblErrorMsg.TabIndex = 5;
            // 
            // lblNewDate
            // 
            this.lblNewDate.AutoSize = true;
            this.lblNewDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNewDate.ForeColor = System.Drawing.Color.SaddleBrown;
            this.lblNewDate.Location = new System.Drawing.Point(192, 308);
            this.lblNewDate.Name = "lblNewDate";
            this.lblNewDate.Size = new System.Drawing.Size(0, 20);
            this.lblNewDate.TabIndex = 6;
            // 
            // lblDateAddHeader
            // 
            this.lblDateAddHeader.AutoSize = true;
            this.lblDateAddHeader.Font = new System.Drawing.Font("Times New Roman", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateAddHeader.Location = new System.Drawing.Point(176, 17);
            this.lblDateAddHeader.Name = "lblDateAddHeader";
            this.lblDateAddHeader.Size = new System.Drawing.Size(296, 36);
            this.lblDateAddHeader.TabIndex = 7;
            this.lblDateAddHeader.Text = "Date Add Application";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblDateAddHeader);
            this.groupBox1.Controls.Add(this.lblNewDate);
            this.groupBox1.Controls.Add(this.lblErrorMsg);
            this.groupBox1.Controls.Add(this.btnNewDate);
            this.groupBox1.Controls.Add(this.txtNoOfDays);
            this.groupBox1.Controls.Add(this.dtPicker);
            this.groupBox1.Controls.Add(this.lblNoOfDays);
            this.groupBox1.Controls.Add(this.lblDate);
            this.groupBox1.Location = new System.Drawing.Point(58, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(671, 422);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // DateAddApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "DateAddApplication";
            this.Text = "Date Add Application";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblNoOfDays;
        private System.Windows.Forms.DateTimePicker dtPicker;
        private System.Windows.Forms.TextBox txtNoOfDays;
        private System.Windows.Forms.Button btnNewDate;
        private System.Windows.Forms.Label lblErrorMsg;
        private System.Windows.Forms.Label lblNewDate;
        private System.Windows.Forms.Label lblDateAddHeader;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

