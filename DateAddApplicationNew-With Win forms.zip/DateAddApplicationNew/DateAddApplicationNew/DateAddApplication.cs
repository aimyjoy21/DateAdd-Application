﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DateAddApplicationNew
{
    public partial class DateAddApplication : Form
    {
      
        public DateAddApplication()
        {
            InitializeComponent();
        }
               
        //For validating the entered value in No.Of days Add field
        private void txtNoOfDays_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verify that the pressed key isn't CTRL or any non-numeric digit
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
                lblErrorMsg.Text = "Invalid Data.Please enter valid number";
            }
            else
                lblErrorMsg.Text = "";
        }
        //Button Click for calculated Date
        private void btnNewDate_Click(object sender, EventArgs e)
        {
            int d1, m1, y1,m2,d2;
            int x = Convert.ToUInt16(txtNoOfDays.Text);           
            string[] subs = dtPicker.Text.Split('/');


            d1 = Convert.ToInt32(subs[0]);
            m1 = Convert.ToInt32(subs[1]);
            y1 = Convert.ToInt32(subs[2]);
            int offset1 = offsetDays(d1, m1, y1);
            int remDays = isLeap(y1) ? (366 - offset1) : (365 - offset1);
            int y2, offset2 = 0;
            if (x <= remDays)
            {
                y2 = y1;
                offset2 = offset1 + x;
            }

            else
            {
                x -= remDays;
                y2 = y1 + 1;
                int y2days = isLeap(y2) ? 366 : 365;
                while (x >= y2days)
                {
                    x -= y2days;
                    y2++;
                    y2days = isLeap(y2) ? 366 : 365;
                }
                offset2 = x;
            }
            revoffsetDays(offset2, y2,out d2,out m2);
          lblNewDate.Text="New Date :"+ d2 + "/" + m2 + "/" + y2;
        }

        //Function to check whether the selected year is leap year or not
        static bool isLeap(int y)
        {
            if (y % 100 != 0 && y % 4 == 0 || y % 400 == 0)
                return true;

            return false;
        }
        //Days offset in selected year
        static int offsetDays(int d, int m, int y)
        {
            int offset = d;

            if (m - 1 == 11)
                offset += 335;
            if (m - 1 == 10)
                offset += 304;
            if (m - 1 == 9)
                offset += 273;
            if (m - 1 == 8)
                offset += 243;
            if (m - 1 == 7)
                offset += 212;
            if (m - 1 == 6)
                offset += 181;
            if (m - 1 == 5)
                offset += 151;
            if (m - 1 == 4)
                offset += 120;
            if (m - 1 == 3)
                offset += 90;
            if (m - 1 == 2)
                offset += 59;
            if (m - 1 == 1)
                offset += 31;

            if (isLeap(y) && m > 2)
                offset += 1;

            return offset;
        }
        //Calculate new date and month
        static void revoffsetDays(int offset, int y,out int d2,out int m2)
        {
            int[] month = { 0, 31, 28, 31, 30, 31, 30,
                    31, 31, 30, 31, 30, 31 };

            if (isLeap(y))
                month[2] = 29;
            int i;
            for (i = 1; i <= 12; i++)
            {
                if (offset <= month[i])
                    break;
                offset = offset - month[i];
            }

            d2 = offset;
            m2 = i;
        }
    }
}
