﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DateTimeCSharp
{
    class DateTimeClass
    {
        static int m2, d2;
        static DateTime userDateTime;
        static int noOfDays;
        static bool isCorrect;
        static void Main(string[] args)
        {
            DateTimeClass dateTimeSample = new DateTimeClass();
            Console.Write("/*********************************************************");
            Console.Write("\n\n               Date Add Application                     ");
            Console.Write("\n\n*********************************************************/\n\n");
            dateTimeSample.program();
            Console.ReadKey();
        }
        private void program()
        {
            int inputval;
            DateTimeClass dateTimeSample = new DateTimeClass();
            dateTimeSample.ReadInput();
            if (isCorrect)
            { dateTimeSample.addDays(userDateTime.Date, noOfDays); }
            Console.Write("\n\nIf you want to Continue Press 1 : ");
            if (Int32.TryParse(Console.ReadLine(), out inputval))
            {
                if (inputval == 1)
                    dateTimeSample.program();
                else
                    Console.Write("\n\nExting......\n\n");
            }

        }

        private void ReadInput()
        {
            Console.Write("Enter a date in dd/mm/yyyy format (e.g. 10/12/1987): ");
            if (DateTime.TryParse(Console.ReadLine(), out userDateTime))
            {
                if (userDateTime.Year > 1900)
                {
                    Console.Write("Enter number of days need to add: ");
                    if (!Int32.TryParse(Console.ReadLine(), out noOfDays))
                    {
                        Console.WriteLine("You have entered an incorrect value for no.of days it should be a number.");
                        isCorrect = false;
                    }
                    isCorrect = true;
                }
                else
                {
                    Console.WriteLine("\n Year should be 4 digit and greater than  1900");
                    isCorrect = false;
                }
            }
            else
            {
                Console.WriteLine("You have entered an incorrect value.It should be in dd/mm/yyyy format");
                Console.WriteLine("\n Date can be ranged from 1-31");
                Console.WriteLine("\n Month can be ranged from 1-12");
                Console.WriteLine("\n Year should be 4 digit and greater than 1900.");
                Console.WriteLine("\n If you provide year as digits 00-50 then it starts from 2000-2049 \n If it is in between 50-99 then it starts from 1950-1999");
                isCorrect = false;
            }

        }
        static bool isLeap(int y)
        {
            if (y % 100 != 0 && y % 4 == 0 || y % 400 == 0)
                return true;

            return false;
        }
        static int offsetDays(int d, int m, int y)
        {
            int offset = d;

            if (m - 1 == 11)
                offset += 335;
            if (m - 1 == 10)
                offset += 304;
            if (m - 1 == 9)
                offset += 273;
            if (m - 1 == 8)
                offset += 243;
            if (m - 1 == 7)
                offset += 212;
            if (m - 1 == 6)
                offset += 181;
            if (m - 1 == 5)
                offset += 151;
            if (m - 1 == 4)
                offset += 120;
            if (m - 1 == 3)
                offset += 90;
            if (m - 1 == 2)
                offset += 59;
            if (m - 1 == 1)
                offset += 31;

            if (isLeap(y) && m > 2)
                offset += 1;

            return offset;
        }
        static void revoffsetDays(int offset, int y)
        {
            int[] month = { 0, 31, 28, 31, 30, 31, 30,
                    31, 31, 30, 31, 30, 31 };

            if (isLeap(y))
                month[2] = 29;
            int i;
            for (i = 1; i <= 12; i++)
            {
                if (offset <= month[i])
                    break;
                offset = offset - month[i];
            }

            d2 = offset;
            m2 = i;
        }
        private void addDays(DateTime date, int x)
        {
            int d1, m1, y1;
            string[] subs = date.ToString("dd/MM/yyyy").Split('-');
            d1 = Convert.ToInt32(subs[0]);
            m1 = Convert.ToInt32(subs[1]);
            y1 = Convert.ToInt32(subs[2]);
            int offset1 = offsetDays(d1, m1, y1);
            int remDays = isLeap(y1) ? (366 - offset1) : (365 - offset1);
            int y2, offset2 = 0;
            if (x <= remDays)
            {
                y2 = y1;
                offset2 = offset1 + x;
            }

            else
            {
                x -= remDays;
                y2 = y1 + 1;
                int y2days = isLeap(y2) ? 366 : 365;
                while (x >= y2days)
                {
                    x -= y2days;
                    y2++;
                    y2days = isLeap(y2) ? 366 : 365;
                }
                offset2 = x;
            }
            revoffsetDays(offset2, y2);
            Console.WriteLine("New Date = " + d2 + "/" + m2 + "/" + y2);
        }


    }
}
