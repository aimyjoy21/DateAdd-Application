This Application is intend to add days to a datetime without using datetime add library functions
This is applicable for datetime >1900
 .exe file is also attached you can directly execute the application through .exe file 
If you need to build the solution in your system then source code also attached