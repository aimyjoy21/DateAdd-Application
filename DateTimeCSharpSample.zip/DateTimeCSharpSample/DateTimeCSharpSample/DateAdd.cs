﻿using System;

namespace DateTimeCSharpSamples
{
    public class DateAdd
    {
        static void Main(string[] args)
        {
            DateAdd dateAdd = new DateAdd();
            Console.Write("/*********************************************************");
            Console.Write("\n\n               Date Add Application                     ");
            Console.Write("\n\n*********************************************************/\n\n");
            dateAdd.BeginApplication();
            Console.ReadKey();
        }
        //Application Start
        private void BeginApplication()
        {
            DateAdd dateAdd = new DateAdd();
            dateAdd.ReadInput(out DateTime userDateTime, out int noOfDays, out bool isCorrect);
            if (isCorrect)
            {
                dateAdd.AddDays(userDateTime.Date, noOfDays);
            }
            Console.Write("\n\n If you want to Continue Press 1 : ");
            if (Int32.TryParse(Console.ReadLine(), out int inputval))
            {
                if (inputval == 1)
                    dateAdd.BeginApplication();
                else
                    Console.Write("\n\n Exting......\n\n");
            }

        }

        //Reading Values from console
        private void ReadInput(out DateTime userDateTime, out int noOfDays, out bool isCorrect)
        {
            noOfDays = 0;
            Console.Write("\n Enter a date in dd/mm/yyyy format (e.g. 10/12/1987): ");
            if (DateTime.TryParse(Console.ReadLine(), out userDateTime))
            {
                if (userDateTime.Year > 1900)
                {
                    Console.Write("\n Enter number of days need to add: ");
                    if (!Int32.TryParse(Console.ReadLine(), out noOfDays))
                    {
                        Console.WriteLine("\n You have entered an incorrect value for no.of days it should be a number.");
                        isCorrect = false;
                    }
                    isCorrect = true;
                }
                else
                {
                    Console.WriteLine("\n Year should be 4 digit and greater than  1900");
                    isCorrect = false;
                }
            }
            else
            {
                Console.WriteLine("\n You have entered an incorrect value.It should be in dd/mm/yyyy format");
                Console.WriteLine("\n Date can be ranged from 1-31");
                Console.WriteLine("\n Month can be ranged from 1-12");
                Console.WriteLine("\n Year should be 4 digit and greater than 1900.");
                Console.WriteLine("\n If you provide year as digits 00-50 then it starts from 2000-2049");
                Console.WriteLine("\n If it is in between 50-99 then it starts from 1950-1999");
                isCorrect = false;
            }

        }
        //Function to check whether the yesr is leap yesr or not
        public static bool IsLeap(int y)
        {
            if (y % 100 != 0 && y % 4 == 0 || y % 400 == 0)
                return true;

            return false;
        }

        //Function to get the days offset in the entered date
        public static int OffsetDays(int d, int m, int y)
        {
            int offset = d;
            if (m - 1 == 11)
                offset += 335;
            if (m - 1 == 10)
                offset += 304;
            if (m - 1 == 9)
                offset += 273;
            if (m - 1 == 8)
                offset += 243;
            if (m - 1 == 7)
                offset += 212;
            if (m - 1 == 6)
                offset += 181;
            if (m - 1 == 5)
                offset += 151;
            if (m - 1 == 4)
                offset += 120;
            if (m - 1 == 3)
                offset += 90;
            if (m - 1 == 2)
                offset += 59;
            if (m - 1 == 1)
                offset += 31;

            if (IsLeap(y) && m > 2)
                offset += 1;
            return offset;
        }

        //Function to get new Date and Month
        public static void RevoffsetDays(int offset, int y, out int d2, out int m2)
        {
            int[] month = { 0, 31, 28, 31, 30, 31, 30,
                    31, 31, 30, 31, 30, 31 };
            if (IsLeap(y))
                month[2] = 29;
            int i;
            for (i = 1; i <= 12; i++)
            {
                if (offset <= month[i])
                    break;
                offset = offset - month[i];
            }
            d2 = offset;
            m2 = i;
        }

        //Function to calculate new date
        public void AddDays(DateTime date, int x)
        {
            int d1, m1, y1, d2, m2;
            string[] subs = date.ToString("dd/MM/yyyy").Split('-');
            d1 = Convert.ToInt32(subs[0]);
            m1 = Convert.ToInt32(subs[1]);
            y1 = Convert.ToInt32(subs[2]);
            int offset1 = OffsetDays(d1, m1, y1);
            int remDays = IsLeap(y1) ? (366 - offset1) : (365 - offset1);
            int y2, offset2 = 0;
            if (x <= remDays)
            {
                y2 = y1;
                offset2 = offset1 + x;
            }
            else
            {
                x -= remDays;
                y2 = y1 + 1;
                int y2days = IsLeap(y2) ? 366 : 365;
                while (x >= y2days)
                {
                    x -= y2days;
                    y2++;
                    y2days = IsLeap(y2) ? 366 : 365;
                }
                offset2 = x;
            }
            RevoffsetDays(offset2, y2, out d2, out m2);
            Console.WriteLine("\n\n New Date is  " + d2 + "/" + m2 + "/" + y2);
        }
    }
}
