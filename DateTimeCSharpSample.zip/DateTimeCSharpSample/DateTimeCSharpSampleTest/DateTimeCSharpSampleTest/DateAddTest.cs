﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DateTimeCSharpSamples;

namespace DateTimeCSharpSampleTest
{
    [TestClass]
    public class DateAddTest
    {
        public static DateAdd dateAdd;
        
        // Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void DateAddTestInitialize(TestContext testContext)
        {
            dateAdd = new DateAdd();
        }
        [TestMethod]
        public void TestOffsetDays()
        {
            int result = DateAdd.OffsetDays(10,12,2021);
            Assert.IsNotNull(result);           
        }
        [TestMethod]
        public void TestOffsetDaysWithinvalid()
        {
            int result = DateAdd.OffsetDays(100, 12, 2021);
            Assert.IsNotNull(result);
        }
        [TestMethod]
        public void TestIsNotLeapYear()
        {
            var isLeapYear = DateAdd.IsLeap(2019);
            Assert.IsFalse(isLeapYear);
        }
        [TestMethod]
        public void TestIsLeapYear()
        {
            var isLeapYear = DateAdd.IsLeap(2020);
            Assert.IsTrue(isLeapYear);
        }

        [TestMethod]
        public void TestRevoffsetDays()
        {
            dateAdd.AddDays(DateTime.Now, 23);
            Assert.IsNotNull(DateTime.Now.AddDays(23));
        }
    }
}
